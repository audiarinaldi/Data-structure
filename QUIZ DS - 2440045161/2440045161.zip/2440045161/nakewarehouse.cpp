#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

const int hashSize = 55;
int lastid = 0;
int counter = 0;

struct shoe {
	char id[10];
	char name[100];
	char category[100];
	char brand[100];
	int stock;
	int price;
	struct shoe *next;
	struct shoe *curr = NULL;
};

shoe *hash[hashSize + 1];

shoe *createNewShoe(char id[], char name[], char category[], char brand[], int stock, int price) {
	shoe *curr= (shoe*)malloc(sizeof(shoe));
	strcpy(curr->id,id);
	strcpy(curr->name,name);
	strcpy(curr->category,category);
	strcpy(curr->brand,brand);
	curr->stock = stock;
	curr->price = price;
	curr->next = NULL;
	
	return curr;
}

int hashFunction (char id[]) {
	int total = 0;
	int len = strlen(id);
	for (int i = 0 ; i < len ; i++) {
		total = total + id[i];
	}
	return total % hashSize;
}

void insertHash(char id[], char name[], char category[], char brand[], int stock, int price) {
	shoe *insert= createNewShoe (id,name,category,brand,stock,price);
	int key = hashFunction(id);
	if (hash[key] == NULL) {
		hash[key] = insert;
	}
	else {
		shoe *temp = hash[key];
		while (temp->next != NULL) {
			temp =temp->next;
		}
		temp->next= insert;
	}
}

bool validateName(char name[]) {
	int len = strlen(name);
	if(len >= 5 && len <= 24) {
		return true;
	}
	return false;
}

bool validateCategory(char category[]) {
	if(strcmp(category, "Shoes") == 0 || strcmp(category, "Bag") == 0) {
		return true;
	}
	return false;
}

bool validateBrand(char brand[]) {
	if(strcmp(brand, "Nike") == 0 || strcmp(brand, "Adidas") == 0) {
		return true;
	}
	return false;
}

void view() {
	if(counter <= 0) {
		printf("There is No Data !\n");
	}
	int counterview = 1;
    for(int i = 0; i < hashSize; i++) {
        shoe *temp = hash[i];
        while(temp != NULL) {
            printf("===========================================================================\n");
            printf("| No |   ID   |  Product Name  |   Category   |  Brand  | Stock |  Price  |\n");
            printf("===========================================================================\n");
            printf("| %-3d| %-7s| %-15s| %-13s| %-8s| %-6d| %-7d |\n", counterview++, temp->id, temp->name, temp->category, temp->brand, temp->stock, temp->price);
            printf("===========================================================================\n");
            temp = temp->next;
        }
    }
}

void deleteShoe() {
	char id[10];
	int enter;
	view();
	printf ("Input ItemID to delete (case insensitive) : ");
	scanf ("%[^\n]",id); getchar();
	
	int key = hashFunction(id);
	if(hash[key] == NULL){
		printf("There is No Data ! \n");
		return;
	}
	
	if (strcmp(hash[key]->id, id)==0){
		shoe *temp = hash[key]->next;
		free(hash[key]);
		hash[key] = temp;
	} else {
		shoe *temp = hash[key];
		while(temp->next != NULL){
			if(strcmp(temp->id, id)==0){
				shoe *temp2 = temp->next;
				temp->next = temp2->next;
				free(temp2);
				return;
			}
			temp = temp->next;
		}
		printf("There is No Data !\n");
		printf("Press Enter to Continue....\n");
		scanf("%[^\n]" ,&enter);
	}

}

void insertShoe(){
	lastid++;
	int temp = lastid;
	int len;
	char id[10];
	char name[100];
	char category[100];
	char brand[100];
	int stock;
	int price;

	
	id[0] = 'N';
    id[1] = 'K';
    id[2] = 'W';
    for (int i = 4; i >= 3; --i){
        id[i] = temp % 10 + '0';
        temp /= 10;
    }
    
    id[5] = '\0';
	
	do {
		printf ("Input Product Name [5 - 24 character]: ");
		scanf ("%[^\n]", name); getchar();
	} while (!validateName (name));	
	
	do {
		printf ("Choose Category [Shoes | Bag] (case sensitive): ");
		scanf ("%[^\n]", category); getchar();
	} while (!validateCategory (category));
	
	do {
		printf ("Choose Brand [Nike | Adidas] (case sensitive) : ");
		scanf ("%[^\n]", brand); getchar();
	} while (!validateBrand (brand));
	
	do {
		printf ("Input Stock [ 50 - 150 ]: ");
		scanf ("%d", &stock); getchar();
	} while (stock<50 || stock>150);
	
	do {
		printf ("Input Price [ 200000 - 1000000 ]: ");
		scanf ("%d", &price); getchar();
	} while (price<200000|| price>1000000);
	
	insertHash (id,name,category,brand,stock,price);
	counter++;
	return;
}

void printMenu(){
	view();
	printf("NAKEWAREHOUSE\n");
	printf("====================\n");
	printf("1. Insert New Product\n");
	printf("2. Delete Product\n");
	printf("3. Exit\n");
	printf(">> ");
}

int main(){
	int menu;
	do {
		printMenu();
		scanf ("%d",&menu);
		getchar();
		if (menu == 1){
			insertShoe();
		}else if (menu == 2){
			deleteShoe();	
		}
	} while (menu!=3);
	return 0;
}
